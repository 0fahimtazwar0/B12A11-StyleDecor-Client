import { Link } from "react-router";
import useAuth from "../../hooks/useAuth";

const Register = () => {
  const handleRegister = (e) => {
    e.preventDefault();
    console.log("hi");
    const authInfo = useAuth;
    console.log(authInfo);
  };

  return (
    <div className='flex flex-col md:flex-row w-fit items-center justify-center gap-10 absolute inset-0 max-width'>
      <div>
        <h2 className='text-4xl md:text-5xl font-bold text-primary'>
          Register Now!
        </h2>
        <p className='mt-2.5'>
          Have an account already?{" "}
          <Link to={"/login"} className='link link-primary'>
            Login
          </Link>
        </p>
      </div>
      <form
        className='fieldset bg-base-200 border-base-300 rounded-box w-full max-w-xs border p-4'
        onSubmit={handleRegister}
      >
        <legend className='fieldset-legend'>Register</legend>

        <label className='label'>Name</label>
        <input type='text' className='input' placeholder='Name' />

        <label className='label'>Email</label>
        <input type='email' className='input' placeholder='Email' />

        <label className='label'>Photo</label>
        <input type='file' className='file-input' />

        <label className='label'>Password</label>
        <input type='password' className='input' placeholder='Password' />

        <button type='submit' className='btn btn-neutral mt-4'>
          Register
        </button>
        <div className='divider'>OR</div>
        <button className='btn bg-white text-black border-[#e5e5e5]'>
          <svg
            aria-label='Google logo'
            width='16'
            height='16'
            xmlns='http://www.w3.org/2000/svg'
            viewBox='0 0 512 512'
          >
            <g>
              <path d='m0 0H512V512H0' fill='#fff'></path>
              <path
                fill='#34a853'
                d='M153 292c30 82 118 95 171 60h62v48A192 192 0 0190 341'
              ></path>
              <path
                fill='#4285f4'
                d='m386 400a140 175 0 0053-179H260v74h102q-7 37-38 57'
              ></path>
              <path
                fill='#fbbc02'
                d='m90 341a208 200 0 010-171l63 49q-12 37 0 73'
              ></path>
              <path
                fill='#ea4335'
                d='m153 219c22-69 116-109 179-50l55-54c-78-75-230-72-297 55'
              ></path>
            </g>
          </svg>
          Login with Google
        </button>
      </form>
    </div>
  );
};

export default Register;
